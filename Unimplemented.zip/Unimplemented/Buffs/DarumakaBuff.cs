using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class DarumakaBuff : PokeBuff
	{
		public override float id {get{return 554f;}}
	}
}
