using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class MisdreavusBuff : PokeBuff
	{
		public override float id {get{return 200f;}}
	}
}
