using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class SigilyphBuff : PokeBuff
	{
		public override float id {get{return 561f;}}
	}
}
