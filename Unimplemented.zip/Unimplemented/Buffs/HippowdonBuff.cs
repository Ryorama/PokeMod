using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class HippowdonBuff : PokeBuff
	{
		public override float id {get{return 450f;}}
	}
}
