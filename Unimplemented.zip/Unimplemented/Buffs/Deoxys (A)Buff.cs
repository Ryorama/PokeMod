using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class DeoxysA : PokeBuff
	{
		public override float id {get{return 386.1f;}}
	}
}
