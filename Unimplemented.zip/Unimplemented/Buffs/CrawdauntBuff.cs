using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CrawdauntBuff : PokeBuff
	{
		public override float id {get{return 342f;}}
	}
}
