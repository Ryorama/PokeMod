using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class FinneonBuff : PokeBuff
	{
		public override float id {get{return 456f;}}
	}
}
