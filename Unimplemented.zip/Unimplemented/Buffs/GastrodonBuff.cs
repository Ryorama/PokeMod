using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class GastrodonBuff : PokeBuff
	{
		public override float id {get{return 423f;}}
	}
}
