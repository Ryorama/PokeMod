using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CacneaBuff : PokeBuff
	{
		public override float id {get{return 331f;}}
	}
}
