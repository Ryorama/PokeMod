using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class GlalieBuff : PokeBuff
	{
		public override float id {get{return 362f;}}
	}
}
