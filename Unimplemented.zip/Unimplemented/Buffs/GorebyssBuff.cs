using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class GorebyssBuff : PokeBuff
	{
		public override float id {get{return 368f;}}
	}
}
