using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class LedianBuff : PokeBuff
	{
		public override float id {get{return 166f;}}
	}
}
