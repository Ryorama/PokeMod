using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class FerroseedBuff : PokeBuff
	{
		public override float id {get{return 597f;}}
	}
}
