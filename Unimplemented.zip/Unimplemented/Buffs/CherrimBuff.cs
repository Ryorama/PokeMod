using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CherrimBuff : PokeBuff
	{
		public override float id {get{return 421f;}}
	}
}
