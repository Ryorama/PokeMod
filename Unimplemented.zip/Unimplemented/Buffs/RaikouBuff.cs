using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class RaikouBuff : PokeBuff
	{
		public override float id {get{return 243f;}}
	}
}
