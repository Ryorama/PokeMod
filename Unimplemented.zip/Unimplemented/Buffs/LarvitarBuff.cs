using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class LarvitarBuff : PokeBuff
	{
		public override float id {get{return 246f;}}
	}
}
