using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class FraxureBuff : PokeBuff
	{
		public override float id {get{return 611f;}}
	}
}
