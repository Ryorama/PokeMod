using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ChimcharBuff : PokeBuff
	{
		public override float id {get{return 390f;}}
	}
}
