using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class AzurillBuff : PokeBuff
	{
		public override float id {get{return 298f;}}
	}
}
