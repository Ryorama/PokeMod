using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class MusharnaBuff : PokeBuff
	{
		public override float id {get{return 518f;}}
	}
}
