using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CofagrigusBuff : PokeBuff
	{
		public override float id {get{return 563f;}}
	}
}
