using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class PorygonBuff : PokeBuff
	{
		public override float id {get{return 137f;}}
	}
}
