using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class SnoverBuff : PokeBuff
	{
		public override float id {get{return 459f;}}
	}
}
