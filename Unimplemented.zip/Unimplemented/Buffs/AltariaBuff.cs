using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class AltariaBuff : PokeBuff
	{
		public override float id {get{return 334f;}}
	}
}
