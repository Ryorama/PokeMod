using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class RayquazaBuff : PokeBuff
	{
		public override float id {get{return 384f;}}
	}
}
