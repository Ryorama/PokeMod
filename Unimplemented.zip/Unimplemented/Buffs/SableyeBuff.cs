using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class SableyeBuff : PokeBuff
	{
		public override float id {get{return 302f;}}
	}
}
