using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class HoundourBuff : PokeBuff
	{
		public override float id {get{return 228f;}}
	}
}
