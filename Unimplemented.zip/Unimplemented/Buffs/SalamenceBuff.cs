using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class SalamenceBuff : PokeBuff
	{
		public override float id {get{return 373f;}}
	}
}
