using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ChandelureBuff : PokeBuff
	{
		public override float id {get{return 609f;}}
	}
}
