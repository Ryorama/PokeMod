using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CarracostaBuff : PokeBuff
	{
		public override float id {get{return 565f;}}
	}
}
