using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class RegigigasBuff : PokeBuff
	{
		public override float id {get{return 486f;}}
	}
}
