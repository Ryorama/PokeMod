using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class MedichamBuff : PokeBuff
	{
		public override float id {get{return 308f;}}
	}
}
