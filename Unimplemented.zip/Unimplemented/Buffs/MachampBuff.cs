using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class MachampBuff : PokeBuff
	{
		public override float id {get{return 68f;}}
	}
}
