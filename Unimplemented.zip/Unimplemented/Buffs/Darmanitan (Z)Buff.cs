using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class DarmanitanZ : PokeBuff
	{
		public override float id {get{return 555.1f;}}
	}
}
