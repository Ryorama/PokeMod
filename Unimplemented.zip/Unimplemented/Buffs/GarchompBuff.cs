using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class GarchompBuff : PokeBuff
	{
		public override float id {get{return 445f;}}
	}
}
