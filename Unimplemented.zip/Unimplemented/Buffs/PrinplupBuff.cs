using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class PrinplupBuff : PokeBuff
	{
		public override float id {get{return 394f;}}
	}
}
