using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class DucklettBuff : PokeBuff
	{
		public override float id {get{return 580f;}}
	}
}
