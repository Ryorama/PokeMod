using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CelebiBuff : PokeBuff
	{
		public override float id {get{return 251f;}}
	}
}
