using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class SeakingBuff : PokeBuff
	{
		public override float id {get{return 119f;}}
	}
}
