using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class PawniardBuff : PokeBuff
	{
		public override float id {get{return 624f;}}
	}
}
