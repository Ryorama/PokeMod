using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ScraftyBuff : PokeBuff
	{
		public override float id {get{return 560f;}}
	}
}
