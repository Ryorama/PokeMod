using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ArcanineBuff : PokeBuff
	{
		public override float id {get{return 59f;}}
	}
}
