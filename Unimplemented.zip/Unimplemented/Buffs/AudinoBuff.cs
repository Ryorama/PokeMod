using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class AudinoBuff : PokeBuff
	{
		public override float id {get{return 531f;}}
	}
}
