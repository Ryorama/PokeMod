using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class AccelgorBuff : PokeBuff
	{
		public override float id {get{return 617f;}}
	}
}
