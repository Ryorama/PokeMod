using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class LiepardBuff : PokeBuff
	{
		public override float id {get{return 510f;}}
	}
}
