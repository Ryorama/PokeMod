using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class LickilickyBuff : PokeBuff
	{
		public override float id {get{return 463f;}}
	}
}
