using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ExeggcuteBuff : PokeBuff
	{
		public override float id {get{return 102f;}}
	}
}
