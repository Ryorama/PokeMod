using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class RotomCut : PokeBuff
	{
		public override float id {get{return 479.5f;}}
	}
}
