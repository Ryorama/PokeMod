using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class OmanyteBuff : PokeBuff
	{
		public override float id {get{return 138f;}}
	}
}
