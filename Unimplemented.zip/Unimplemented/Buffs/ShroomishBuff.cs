using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ShroomishBuff : PokeBuff
	{
		public override float id {get{return 285f;}}
	}
}
