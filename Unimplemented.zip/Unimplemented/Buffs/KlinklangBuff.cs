using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class KlinklangBuff : PokeBuff
	{
		public override float id {get{return 601f;}}
	}
}
