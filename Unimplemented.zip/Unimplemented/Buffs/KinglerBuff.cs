using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class KinglerBuff : PokeBuff
	{
		public override float id {get{return 99f;}}
	}
}
