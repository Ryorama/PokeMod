using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class HaunterBuff : PokeBuff
	{
		public override float id {get{return 93f;}}
	}
}
