using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class MagnezoneBuff : PokeBuff
	{
		public override float id {get{return 462f;}}
	}
}
