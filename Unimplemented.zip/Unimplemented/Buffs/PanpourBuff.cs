using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class PanpourBuff : PokeBuff
	{
		public override float id {get{return 515f;}}
	}
}
