using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class DeoxysS : PokeBuff
	{
		public override float id {get{return 386.3f;}}
	}
}
