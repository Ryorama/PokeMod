using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class GirafarigBuff : PokeBuff
	{
		public override float id {get{return 203f;}}
	}
}
