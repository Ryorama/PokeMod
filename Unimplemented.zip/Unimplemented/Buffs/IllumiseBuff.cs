using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class IllumiseBuff : PokeBuff
	{
		public override float id {get{return 314f;}}
	}
}
