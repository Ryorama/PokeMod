using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class KricketuneBuff : PokeBuff
	{
		public override float id {get{return 402f;}}
	}
}
