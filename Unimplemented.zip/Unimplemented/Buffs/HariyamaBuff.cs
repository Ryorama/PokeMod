using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class HariyamaBuff : PokeBuff
	{
		public override float id {get{return 297f;}}
	}
}
