using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class CleffaBuff : PokeBuff
	{
		public override float id {get{return 173f;}}
	}
}
