using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class FloatzelBuff : PokeBuff
	{
		public override float id {get{return 419f;}}
	}
}
