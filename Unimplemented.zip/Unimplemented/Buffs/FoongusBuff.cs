using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class FoongusBuff : PokeBuff
	{
		public override float id {get{return 590f;}}
	}
}
