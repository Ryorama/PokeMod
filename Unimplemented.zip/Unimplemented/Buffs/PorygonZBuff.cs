using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class PorygonZBuff : PokeBuff
	{
		public override float id {get{return 474f;}}
	}
}
