using System;
using Terraria;
using Terraria.ModLoader;

namespace PokeModBlue.Buffs {

	public class ChikoritaBuff : PokeBuff
	{
		public override float id {get{return 152f;}}
	}
}
